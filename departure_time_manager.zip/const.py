DOMAIN = "departure_time_manager"
INTEGRATION_NAME = "Departure Time Manager"
